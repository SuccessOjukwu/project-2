#@LeavingCertGrades.py
#this program to calculate leaving cert grades
#of two students and the points each of them achieved
#it also uses while loop and for loop to get grades and
#tells the user who got the highest points
#@authorSOjukwu
#@version 1.00 2020/10/20

#assign variables

point=0
total=0
lowest=101
total1=0
total2=0

#prompt  student1 to input name and grades
#executes grades using for loop

student1=input("Enter in your name")
for x in range (1,8):
  grade=int(input("Enter in your grade"+str(x)+":"))
  x+=1
    
#uses if statements to determine points for each grade
#as well as the lowest points.
 
  if grade>=90:
   point=100
   print("H1, "+str(point))
   if grade<lowest:
    lowest=point
  elif grade>=80:
    point=88
    print("H2, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=70:
    point=77
    print("H3, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=60:
    point=66
    print("H4, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=50:
    point=56
    print("H5, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=40:
    point=46
    print("H6, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=30:
    point=37
    print("H7, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=0:
    point=0
    print("H8, "+str(point))
    lowest=0
  else:
    print("invalid")
    
#to calculate total points for student1
  total=total+point
  
#to print the total point and lowest point to screen 
print(total,lowest)

#to print total point subtracted from the lowest
print("Your total points are "+ str(total-lowest))

#assign variables to calulate highest grade
total1=total

#assign  new variables

total=0
point=0
lowest=101

#prompt student2 for name and grades
#executes grades using while loop

student2=input("Enter in your name")     
x=1
while (x<8):
  grade=int(input("Enter in your grade"+str(x)+":"))
  x+=1
  
  #uses if statement to determine points for each grade
  
  if grade>=90:
   point=100
   print("H1, "+str(point))
   if grade<lowest:
    lowest=point
  elif grade>=80:
    point=88
    print("H2, "+str(point))   
    if grade<lowest:
     lowest1=point
  elif grade>=70:
    point=77
    print("H3, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=60:
    point=66
    print("H4, "+str(point))
    if grade<lowest:
     lowest=point
  elif grade>=50:
    point=46
    print("H5, "+str(point))   
    if grade<lowest:
     lowest=point
  elif grade>=40:
    point=46
    print("H6, "+str(point))   
    if grade<lowest:
     lowest=point
  elif grade>=30:
    point=37
    print("H7, "+str(point))   
    if grade<lowest:
     lowest=point
  elif grade>=0:
    point=0 
    print("H8, "+str(point))
    lowest=0
  else:
    print("invalid")

#to calculate the total points for student2
  total=total+point
  
#to print student2 total and lowest points to screen
print(total,lowest)

#to print student2 lowest point to screen
print("Your total points are "+ str(total- lowest))

#assign a new variable to total 
total2=total

#to find which student got the highest points
#using if statement

if total1>total2:
  print(student1+" got the highest point")
elif total2>total1:
  print(student2+" got the highest point")
else:
 print("You scored the same")
